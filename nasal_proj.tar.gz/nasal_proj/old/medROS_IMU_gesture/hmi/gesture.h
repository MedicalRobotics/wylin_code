#ifndef __GESTURE_H__
#define __GESTURE_H__

#define MAX_TRIG_NUM 10

class imu_gesture {
private:
    int head, tail;
    float ref_YPR[3], YPR[3];
    float trig[MAX_TRIG_NUM][3];
    float Threshold[3]; // [0]:control direction [1]:switch control axis [2]:control mode - down:switch axis; up-control direction
    int tty_fd;

private:
    int init_serialport(char* port);//"/dev/ttyUSB0"
    int clock_sub(float sub[3], const float val[3], const float ref_val[3]);
    int scan_YPR(char *pst, int len);

public:
    imu_gesture();
    int set_refYPR();
    int monitor_serialport();
    int start(char* port);
    int stop();
    int show_delta();
    int calculate();
};


#endif //__GESTURE_H_