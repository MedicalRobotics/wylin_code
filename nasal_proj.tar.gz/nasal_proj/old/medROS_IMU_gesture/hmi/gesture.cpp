#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>

#include "gesture.h"
#include "../msg/return_code.h"

#define SET3(v, a, b, c) (v)[0]=a, (v)[1]=b, (v)[2]=c

imu_gesture::imu_gesture()
{
    tty_fd = -1;
    head = 0;
    tail = head;
}

int imu_gesture::start(char* port)
{
    int rtn;
    rtn = init_serialport(port);
    if (rtn != RTN_OK) return rtn;

    memset(YPR, 0, sizeof(float)*3);
    memset(ref_YPR, 0, sizeof(float)*3);
    SET3(Threshold, 15, 15, 10);
    return RTN_OK;
}

int imu_gesture::show_delta()
{
    float delta[3];
    clock_sub(delta, YPR, ref_YPR);
    printf("delta:\t%.02f\t%.02f\t%.02f\t\t\r", delta[0], delta[1], delta[2]);
    return RTN_OK;
}

int imu_gesture::stop()
{
    if (tty_fd < 0) return RTN_OK;
    close(tty_fd);
    tty_fd = -1;
    return RTN_OK;
}

int imu_gesture::clock_sub(float sub[3], const float val[3], const float ref_val[3])
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        sub[i] = val[i] - ref_val[i];
        for(j=0; j<10; j++){
            if (sub[i] >= 180) {sub[i] -= 360; continue;}
            if (sub[i] <=-180) {sub[i] += 360; continue;}
            break;
        }
    }
    return RTN_OK;
}

int imu_gesture::set_refYPR()
{
    memcpy(ref_YPR, YPR, sizeof(ref_YPR));
    return RTN_OK;
}

int imu_gesture::init_serialport(char* port)
{
    struct termios tio;
	tty_fd = open(port, O_RDWR | O_NONBLOCK);
    if (tty_fd < 0) {
        printf("Open com port fail\n");
        return RTN_ERROR;
    }else{
        printf("Open com port success\n");
    }

    memset(YPR, 0, sizeof(float)*3);
    memset(ref_YPR, 0, sizeof(float)*3);

    memset(&tio, 0, sizeof(tio));
	tio.c_iflag=0;
	tio.c_oflag=0;
	tio.c_cflag=CS8|CREAD|CLOCAL;           // 8n1, see termios.h for more information
	tio.c_lflag=0;
	tio.c_cc[VMIN]=1;
	tio.c_cc[VTIME]=5;
    cfsetospeed(&tio,B57600);            // 57600 baud
	cfsetispeed(&tio,B57600);            // 57600 baud
	tcsetattr(tty_fd,TCSANOW,&tio);
    return RTN_OK;
}

int imu_gesture::scan_YPR(char *pst, int len)
{
    char st[256];
    int tail=-1;
    float ypr[3];
    int i, n=0;
    memcpy(st, pst, len);
    st[len] = 0;
    for (i = len-1; i >= 0 ; i--) {
        if (st[i] == '\n') tail = len;
        if (st[i] == '#' && tail >= 0) {
            n = sscanf(&st[i], "#YPR=%f,%f,%f", &ypr[0], &ypr[1], &ypr[2]);
            memcpy(YPR, ypr, sizeof(float)*3);
            memcpy(pst, &st[tail], len - tail);
            pst[len-tail] = 0;
            return len - tail;
        }
    }
    return len;
}

int imu_gesture::calculate()
{
    int i;
    float delta[3];
    head = tail;
    tail = (tail+1) % MAX_TRIG_NUM;
    clock_sub(delta, YPR, ref_YPR);
    for (i=0; i<3; i++) {
        if(delta[i] < -Threshold[i]){ trig[tail][i] = -1;}
        else if (delta[i] > Threshold[i]){trig[tail][i] = 1;}
        else {trig[tail][i] = 0;}
    }

    return RTN_OK;
}

int imu_gesture::monitor_serialport()
{
    static char str[1024]={0};
    static int len=0;

    char st[256];
    int n;
    if(tty_fd < 0)  return RTN_OK;
    n = read(tty_fd, st, 255);
    if (n<0) return RTN_OK;

    st[n] = 0;
    memcpy(&str[len], st, n);
    len += n;
    len = scan_YPR(str, len);
    //printf("YPR: %.02f %.02f %.02f     \t\t\r", YPR[0], YPR[1], YPR[2]);
    return RTN_OK;
}
