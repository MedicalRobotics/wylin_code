
#ifndef __MRL_TYPE_H_
#define __MRL_TYPE_H_

typedef long MRLTYPE;

#endif // __MRL_TYPE_H_