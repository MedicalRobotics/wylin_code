#!/bin/bash


/bin/bash -c 'gnome-terminal -x "/home/medros/medROS/main/rcore"' 
/home/medros/medROS/hmi/user
